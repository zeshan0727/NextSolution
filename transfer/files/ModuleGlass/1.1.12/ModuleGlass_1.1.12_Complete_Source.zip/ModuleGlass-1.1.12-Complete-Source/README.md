# Module Glass 1.1.12 Complete Source

RootHide / iOS 16+ Control Center module background runtime.

## 1.1.12 transition recovery

- Removes the 1.1.11 `viewWillLayoutSubviews`, `viewWillDisappear:`, and `viewDidAppear:` expansion hooks that could mutate Apple views during unrelated Control Center, lock, and unlock transitions.
- Uses only `viewWillTransitionToSize:withTransitionCoordinator:` for pre-transition suspension.
- Cleans Module Glass visual state once per transition, then stays completely passive while Apple owns layout.
- Uses generation tokens so stale transition completions cannot restore custom visuals during a newer expansion.
- Restores Module Glass only after compact geometry is stable and no transition coordinator is active.
- Includes a bounded interrupted-transition watchdog so lock/unlock cannot leave the renderer permanently suspended.
- Keeps the validated 1.1.10 image, blur, glow, slider, volume tint, and module-identification behavior unchanged outside expansion handling.
