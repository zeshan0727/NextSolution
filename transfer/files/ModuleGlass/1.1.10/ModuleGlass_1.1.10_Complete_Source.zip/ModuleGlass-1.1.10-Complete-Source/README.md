# Module Glass 1.1.10 Complete RootHide

Slider-shell-only delta from the validated 1.1.9 device build:
- Removes the remaining translucent gray background from Brightness and Volume.
- The slider shell stays full-size and rounded, but its background is fully transparent.
- The existing 0-100% image fill mask, slider geometry, glyphs, percentages and all non-slider rendering behavior are unchanged.
