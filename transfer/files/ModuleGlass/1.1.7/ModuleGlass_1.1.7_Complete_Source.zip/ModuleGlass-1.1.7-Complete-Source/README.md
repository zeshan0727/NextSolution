# Module Glass 1.1.7 Complete RootHide
- Crisp Remove Blur for module-sized non-interactive material surfaces.
- Volume custom image follows live slider value from 0% to 100%, bottom to top, matching Brightness.
