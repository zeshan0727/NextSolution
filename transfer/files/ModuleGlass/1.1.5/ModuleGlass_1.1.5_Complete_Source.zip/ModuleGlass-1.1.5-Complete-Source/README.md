# Module Glass 1.1.5 Complete RootHide

This recovery-first complete package embeds the validated stable Module Glass 1.0.14 renderer directly in `com.nextsolution.nextaura.cc-module-backgrounds`.

It intentionally does not use the failed 1.1.4 hardened renderer. The package provides the historical runtime capability itself and conflicts with standalone renderer versions through 1.1.4 so Sileo/APT cannot leave the crashing renderer installed underneath it.

Shared Settings UI remains provided by `com.nextsolution.nextaura.runtime.preferences >= 1.0.5`, the normal modular NextAura preference runtime.
