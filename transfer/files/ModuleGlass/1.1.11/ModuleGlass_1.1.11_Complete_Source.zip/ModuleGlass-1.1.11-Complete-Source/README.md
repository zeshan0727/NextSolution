# Module Glass 1.1.11 Complete RootHide

Expansion-lifecycle-only delta from the validated 1.1.10 device build:
- Restores Apple module visuals and removes Module Glass image/shell state before expansion transitions.
- Suspends Module Glass rendering while a module is expanded or transitioning.
- Re-enables the unchanged 1.1.10 renderer only after the controller is compact again.
- Existing slider geometry/fill, transparent slider shell, Connectivity glyph handling, blur removal, image sizing and all other visual behavior are unchanged.
