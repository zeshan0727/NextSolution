# Module Glass 1.1.9 Complete RootHide

Slider-only delta from the validated 1.1.8 device build:
- Brightness and Volume no longer use Apple's value-dependent fill/background frame as the custom-image host.
- Both sliders keep one permanent full-height rounded shell at every value.
- Both sliders use the same single rounded custom-image fill mask from 0% to 100%.
- Existing Connectivity, blur removal, image sizing, glyph handling, Focus, Now Playing and standard-module behavior is unchanged.
