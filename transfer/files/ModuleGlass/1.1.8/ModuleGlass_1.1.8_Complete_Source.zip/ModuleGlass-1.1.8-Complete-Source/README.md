# Module Glass 1.1.8 Complete RootHide

Delta from the validated 1.1.7 device build only:
- Volume live fill retains the full Brightness-style pill geometry while revealing from bottom to top.
- Connectivity active blue toggle backgrounds are cleared while native glyphs/controls remain visible and interactive.
- All other 1.1.7 rendering behavior is intentionally unchanged.
