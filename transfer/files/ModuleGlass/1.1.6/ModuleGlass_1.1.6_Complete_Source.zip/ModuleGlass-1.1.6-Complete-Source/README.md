# Module Glass 1.1.6 Complete RootHide

Device-test build implementing three renderer rules:
1. Custom images use ScaleToFill and stretch to the selected compact module shell.
2. Standard modules are background-only; native glyphs, labels, buttons and indicators are never recursively suppressed.
3. Volume and Brightness share the same slider placement, pill geometry and fill-aware cleanup path.

This build stays on the stable recovery renderer foundation and does not restore the failed 1.1.4 hardened renderer.
